package java2.lesson6.server;


import java2.lesson6.server.service.ServerImpl;

public class ChatApp {

    public static void main(String[] args) {
        new ServerImpl();
    }
}
